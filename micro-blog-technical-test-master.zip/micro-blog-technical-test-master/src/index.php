<?php
/* ------- Page Details  --------- 
Author: Memiah Team & Prasad Patil
Updated Date: 03 Aug 2016
Purpose: Blog Application Business Logic
--------- Page Details ---------- */

/* Include all bacic things  */
require_once __DIR__.'/config/index.php';

/* Include for post request response and redirection  */
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\RedirectResponse;

/* ------- micro-blog api ---------
All CRUD operations performed within our /api/ endpoints below
TODO: Error checking - e.g. if try retrieve posts for a user_id that does
      not exist, return an error message and an appropriate HTTP status code.

      Implement /api/posts/new endpoint to add a new micro-blog post for a
      given user.
      Extra: Add new API endpoints for any extra features you can think of.
      Extra: Improve on current API code where you see necessary
*/

/* Define Application Path  */
$protocol = isset($_SERVER["HTTPS"]) ? 'https://' : 'http://';
$rootPath = $protocol . $_SERVER['HTTP_HOST'].'/micro-blog-technical-test-master';
$baseUrlPath = $protocol . $_SERVER['HTTP_HOST'].'/micro-blog-technical-test-master/src/index.php/';
$paths = array('dirpath'=>$rootPath,'baseUrlPath'=>$baseUrlPath);

/* Load Index Page for Application Details */
$app->get('/', function() use($app,$paths) {
  return $app['twig']->render('index.twig',array('path'=>$paths));
});

/* Call Dashbarod Page */
$app->get('/api/dashboard', function() use($app,$paths) {
    return $app['twig']->render('dashboard.twig',array('path'=>$paths));
});

/* Call User Listing Page */
$app->get('/api/users', function() use($app,$paths) {
    $sql = "SELECT rowid, * FROM users";
    $users = $app['db']->fetchAll($sql);
    return $app['twig']->render('users.twig',array('users'=>$users,'path'=>$paths));
});

/* Call All Posts Listing Page */
$app->get('/api/posts', function() use($app,$paths) {
    $sql = "SELECT rowid, * FROM posts";
    $posts = $app['db']->fetchAll($sql);
    return $app['twig']->render('allposts.twig',array('posts'=>$posts,'path'=>$paths)); 
});

/* Call Error Page */
$app->get('/api/errorreport/{error_id}', function($error_id) use($app,$paths) {
   return $app['twig']->render('errormessage.twig',array('errorcode'=>$error_id,'path'=>$paths));
});

/* Call Middleware to check valid user */
$checkValidUsr = function (Request $request) use($app,$paths) {    
    $sql = "SELECT rowid FROM users WHERE user_id = ?";
    $users = $app['db']->fetchAll($sql, array((int) $request->get('user_id')));     
    if(count($users) == 0){
        return $app->redirect($paths['baseUrlPath']."api/errorreport/101");
    }
};

/* Call specific User post listing Page */
$app->get('/api/posts/user/{user_id}', function($user_id) use($app,$paths) {   
    $sql = "SELECT rowid, * FROM posts WHERE user_id = ?";
    $posts = $app['db']->fetchAll($sql, array((int) $user_id));
    return $app['twig']->render('posts.twig',array('posts'=>$posts,'user_id'=>$user_id,'path'=>$paths));       
})->before($checkValidUsr);

/* Call Middleware to check valid post and post user */
$checkValidPost = function (Request $request) use($app,$paths) {    
    $sql = "SELECT rowid,user_id FROM posts WHERE rowid = ?";
    $postSql = $app['db']->fetchAssoc($sql, array((int) $request->get('post_id')));      
    if(empty($postSql)){ 
        return $app->redirect($paths['baseUrlPath']."api/errorreport/102");
    }
    if($postSql['user_id']==0){
        return $app->redirect($paths['baseUrlPath']."api/errorreport/103");
    }
};

/* Call post detail page */
$app->get('/api/posts/id/{post_id}', function($post_id) use($app,$paths) {
    $sql = "SELECT rowid, * FROM posts WHERE rowid = ?";
    $post = $app['db']->fetchAssoc($sql, array((int) $post_id));
    return $app['twig']->render('postsdetails.twig',array('post'=>$post,'path'=>$paths));
})->before($checkValidPost);

/* Call Add post Page */
$app->get('/api/addpost/{user_id}', function($user_id) use($app,$paths) {
    $post = array('title'=>'','content'=>'','user_id'=>$user_id);
    return $app['twig']->render('addpost.twig',array('post'=>$post,'path'=>$paths));
})->before($checkValidUsr);

/* Save post logic */
$app->post('/api/posts/new', function (Request $request) use($app,$paths) {     
    $date = date_create();
    $st = $app['db']->prepare("INSERT INTO posts (title,content,user_id,date) VALUES (?,?,?,?)");
    $st->execute(array($request->get('title'),$request->get('content'),$request->get('user_id'),date_timestamp_get($date)));
    $app['session']->getFlashBag()->add('message', 'Record save successfully!');
    return $app->redirect($paths['baseUrlPath']."api/posts/user/".$request->get('user_id'));
});

/* Call Update Post Page */
$app->get('/api/updatepost/{post_id}', function($post_id) use($app,$paths) {    
    $sql = "SELECT rowid, * FROM posts WHERE rowid = ?";
    $post = $app['db']->fetchAssoc($sql, array((int) $post_id));
    return $app['twig']->render('updatepost.twig',array('post'=>$post,'path'=>$paths));
})->before($checkValidPost);

/* Update post logic */
$app->post('/api/posts/update', function (Request $request) use($app,$paths) {     
    $date = date_create();
    $st = $app['db']->prepare("UPDATE posts SET title = ?, content = ? ,date = ? WHERE rowid = ?");
    $st->execute(array($request->get('title'),$request->get('content'),date_timestamp_get($date),$request->get('post_id')));
    $app['session']->getFlashBag()->add('message', 'Record updated successfully!');
    return $app->redirect($paths['baseUrlPath']."api/posts/id/".$request->get('post_id'));
});

/* Delete Post */
$app->get('/api/posts/delete/{post_id}', function($post_id) use($app,$paths) {    
    $sql = "DELETE FROM posts WHERE rowid = '".$post_id."'";
    $app['db']->exec($sql);
    $app['session']->getFlashBag()->add('message', 'Record deleted successfully!');
    return "1";
});

$app->run();